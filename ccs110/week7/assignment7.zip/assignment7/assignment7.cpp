// Victoria Barnett - CS 110C - Assignment 7 - 04/09/2023
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

//defs
class Stack {
private:
    int top;
    int size;
    int *stackArray;
public:
    Stack(int size);
    ~Stack();
    void push(int value);
    int pop();
    bool isEmpty();
    bool isFull();
    void showStack();
    char peek();
};

Stack::Stack(int size) {
    this->size = size;
    stackArray = new int[size];
    top = -1;
}

Stack::~Stack() {
    delete[] stackArray;
}

void Stack::push(int value) {
    if (isFull()) {
        cout << "Stack is full" << endl;
    }
    else {
        top++;
        stackArray[top] = value;
    }
}

int Stack::pop() {
    if (isEmpty()) {
        cout << "Stack is empty" << endl;
        return -1;
    }
    else {
        int temp = stackArray[top];
        top--;
        return temp;
    }
}

bool Stack::isEmpty() {
    if (top == -1) {
        return true;
    }
    else {
        return false;
    }
}

bool Stack::isFull() {
    if (top == size - 1) {
        return true;
    }
    else {
        return false;
    }
}

void Stack::showStack() {
    for (int i = top; i >= 0; i--) {
        cout << stackArray[i] << " ";
    }
    cout << endl;
}

char Stack::peek() {
    return stackArray[top];
}

//prototypes
void infixToPostfix(string infixExp, string &postfixExp);
void PostfixEval(string postfixExp, int &result);
bool checkValid(string infixExp);

int main(){
    string infixExp;
    string postfixExp;
    int result;
    
    cout << "Enter an infix expression: ";
    cin >> infixExp;

    //check if the expression is valid
    if (!checkValid(infixExp)) {
        cout << "Sorry, this infix won't be valid for this calculator" << endl;
        cout << "Please enter a valid infix expression where all operands are single digits and all parenthesis are balanced. " << endl;
        cout << "Enter an infix expression: ";
        cin >> infixExp;
    }

    infixToPostfix(infixExp, postfixExp);
    cout << "Postfix expression: " << postfixExp << endl;

    PostfixEval(postfixExp, result);
    cout << "Result: " << result << endl;

    return 0;
}

void infixToPostfix(string infixExp, string &postfixExp){
    Stack s(infixExp.length());
    for (int i = 0; i < infixExp.length(); i++) {
        if (infixExp[i] >= '0' && infixExp[i] <= '9') {
            postfixExp += infixExp[i];
        }
        else if (infixExp[i] == '(') {
            s.push(infixExp[i]);
        }
        else if (infixExp[i] == ')') {
            while (s.peek() != '(') {
                postfixExp += s.pop();
            }
            s.pop();
        }
        else if (infixExp[i] == '+' || infixExp[i] == '-' || infixExp[i] == '*' || infixExp[i] == '/') {
            while (!s.isEmpty() && s.peek() != '(') {
                postfixExp += s.pop();
            }
            s.push(infixExp[i]);
        }
    }
    while (!s.isEmpty()) {
        postfixExp += s.pop();
    }
}

void PostfixEval(string postfixExp, int &result){
    Stack s(postfixExp.length());
    for (int i = 0; i < postfixExp.length(); i++) {
        if (postfixExp[i] >= '0' && postfixExp[i] <= '9') {
            s.push(postfixExp[i] - '0');
        }
        else if (postfixExp[i] == '+') {
            int op1 = s.pop();
            int op2 = s.pop();
            s.push(op1 + op2);
        }
        else if (postfixExp[i] == '-') {
            int op1 = s.pop();
            int op2 = s.pop();
            s.push(op2 - op1);
        }
        else if (postfixExp[i] == '*') {
            int op1 = s.pop();
            int op2 = s.pop();
            s.push(op1 * op2);
        }
        else if (postfixExp[i] == '/') {
            int op1 = s.pop();
            int op2 = s.pop();
            s.push(op2 / op1);
        }
    }
    result = s.pop();
}

bool checkValid(string infixExp) {
    for(int i = 0; i < infixExp.length(); i++) {
        if (isdigit(infixExp[i])) {
            if (isdigit(infixExp[i + 1])) {
                return false;
            }
        }
        else if (infixExp[i] == '+' || infixExp[i] == '-' || infixExp[i] == '*' || infixExp[i] == '/') {
            if (infixExp[i + 1] == '+' || infixExp[i + 1] == '-' || infixExp[i + 1] == '*' || infixExp[i + 1] == '/') {
                return false;
            }
        }
        else if (infixExp[i] == '(') {
            if (infixExp[i + 1] == ')') {
                return false;
            }
        }
        else if (infixExp[i] == ')') {
            if (infixExp[i + 1] == '(') {
                return false;
            }
        }
    }
    return true;
}